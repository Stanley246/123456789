import ToolEngine from "./ToolEngine";

interface ToolWorkspaceProps {
  toolId: string;
}

export default function ToolWorkspace({ toolId }: ToolWorkspaceProps) {
  return (
    <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
      <ToolEngine toolId={toolId} />
    </div>
  );
}
