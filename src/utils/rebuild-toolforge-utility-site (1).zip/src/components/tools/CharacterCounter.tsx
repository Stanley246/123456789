import { useState } from "react";

export default function CharacterCounter() {
  const [text, setText] = useState("");

  const total = text.length;
  const noSpaces = text.replace(/\s/g, "").length;
  const letters = (text.match(/[a-zA-Z]/g) || []).length;
  const digits = (text.match(/\d/g) || []).length;
  const spaces = (text.match(/\s/g) || []).length;
  const special = total - letters - digits - spaces;

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Character Counter
      </h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: "Total", value: total, color: "text-brand-500" },
          { label: "No Spaces", value: noSpaces, color: "text-emerald-500" },
          { label: "Letters", value: letters, color: "text-blue-500" },
          { label: "Digits", value: digits, color: "text-amber-500" },
          { label: "Spaces", value: spaces, color: "text-purple-500" },
          { label: "Special", value: special, color: "text-rose-500" },
        ].map((s) => (
          <div
            key={s.label}
            className="text-center p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl"
          >
            <div className={`text-2xl font-bold font-mono ${s.color}`}>
              {s.value}
            </div>
            <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-1">
              {s.label}
            </div>
          </div>
        ))}
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type or paste text to count characters..."
        className="w-full h-48 p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 text-sm resize-y font-sans"
      />
    </div>
  );
}
