import { useState, useCallback } from "react";

export default function PasswordGenerator() {
  const [length, setLength] = useState(16);
  const [uppercase, setUppercase] = useState(true);
  const [lowercase, setLowercase] = useState(true);
  const [numbers, setNumbers] = useState(true);
  const [symbols, setSymbols] = useState(true);
  const [password, setPassword] = useState("");
  const [copied, setCopied] = useState(false);

  const generate = useCallback(() => {
    let chars = "";
    if (uppercase) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (lowercase) chars += "abcdefghijklmnopqrstuvwxyz";
    if (numbers) chars += "0123456789";
    if (symbols) chars += "!@#$%^&*()_+-=[]{}|;:,.<>?";
    if (!chars) chars = "abcdefghijklmnopqrstuvwxyz";

    const arr = new Uint32Array(length);
    crypto.getRandomValues(arr);
    const pwd = Array.from(arr, (v) => chars[v % chars.length]).join("");
    setPassword(pwd);
    setCopied(false);
  }, [length, uppercase, lowercase, numbers, symbols]);

  const getStrength = () => {
    if (!password) return { label: "None", color: "bg-slate-300", pct: 0 };
    let score = 0;
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (password.length >= 16) score++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
    if (/\d/.test(password)) score++;
    if (/[^a-zA-Z0-9]/.test(password)) score++;
    if (score <= 2) return { label: "Weak", color: "bg-red-500", pct: 25 };
    if (score <= 3) return { label: "Fair", color: "bg-amber-500", pct: 50 };
    if (score <= 4) return { label: "Strong", color: "bg-blue-500", pct: 75 };
    return { label: "Very Strong", color: "bg-emerald-500", pct: 100 };
  };

  const strength = getStrength();

  return (
    <div className="space-y-6">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Secure Password Generator
      </h3>

      {/* Generated password display */}
      {password && (
        <div className="relative p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl">
          <div className="font-mono text-lg text-slate-900 dark:text-white break-all leading-relaxed pr-16">
            {password}
          </div>
          <button
            onClick={() => { navigator.clipboard.writeText(password); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
            className="absolute top-4 right-4 px-3 py-1.5 bg-brand-500 text-white text-xs font-bold rounded-lg hover:bg-brand-600 transition-colors cursor-pointer"
          >
            {copied ? "✓ Copied!" : "Copy"}
          </button>
          <div className="mt-3 flex items-center gap-3">
            <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div className={`h-full ${strength.color} rounded-full transition-all duration-300`} style={{ width: `${strength.pct}%` }} />
            </div>
            <span className="text-xs font-bold text-slate-500">{strength.label}</span>
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="space-y-4">
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Length: {length}
            </label>
          </div>
          <input
            type="range"
            min={4}
            max={64}
            value={length}
            onChange={(e) => setLength(Number(e.target.value))}
            className="w-full accent-brand-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Uppercase (A-Z)", checked: uppercase, set: setUppercase },
            { label: "Lowercase (a-z)", checked: lowercase, set: setLowercase },
            { label: "Numbers (0-9)", checked: numbers, set: setNumbers },
            { label: "Symbols (!@#$)", checked: symbols, set: setSymbols },
          ].map((opt) => (
            <label key={opt.label} className="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
              <input
                type="checkbox"
                checked={opt.checked}
                onChange={(e) => opt.set(e.target.checked)}
                className="accent-brand-500 w-4 h-4"
              />
              <span className="text-sm text-slate-700 dark:text-slate-300 font-medium">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      <button
        onClick={generate}
        className="w-full px-5 py-3 bg-brand-500 hover:bg-brand-600 text-white text-sm font-bold rounded-xl transition-fast cursor-pointer"
      >
        Generate Password
      </button>
    </div>
  );
}
