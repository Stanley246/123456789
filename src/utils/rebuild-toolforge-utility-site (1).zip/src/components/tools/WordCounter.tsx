import { useState } from "react";

export default function WordCounter() {
  const [text, setText] = useState("");

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;
  const charsNoSpaces = text.replace(/\s/g, "").length;
  const sentences = text.trim() ? text.split(/[.!?]+/).filter((s) => s.trim()).length : 0;
  const paragraphs = text.trim() ? text.split(/\n\s*\n/).filter((p) => p.trim()).length : 0;
  const readTime = Math.ceil(words / 200);
  const speakTime = Math.ceil(words / 130);

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Word Counter
      </h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: "Words", value: words },
          { label: "Characters", value: chars },
          { label: "No Spaces", value: charsNoSpaces },
          { label: "Sentences", value: sentences },
          { label: "Paragraphs", value: paragraphs },
          { label: "Read Time", value: `${readTime}m` },
        ].map((s) => (
          <div
            key={s.label}
            className="text-center p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl"
          >
            <div className="text-2xl font-bold font-mono text-brand-500">
              {s.value}
            </div>
            <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-1">
              {s.label}
            </div>
          </div>
        ))}
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Start typing or paste your text here to count words, characters, sentences, and more..."
        className="w-full h-56 p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 text-sm resize-y font-sans leading-relaxed"
      />

      {text.trim() && (
        <div className="text-xs text-slate-500 dark:text-slate-400">
          📖 Reading: ~{readTime} min &nbsp;|&nbsp; 🗣️ Speaking: ~{speakTime} min
        </div>
      )}
    </div>
  );
}
