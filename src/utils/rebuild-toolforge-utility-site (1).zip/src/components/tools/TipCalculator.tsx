import { useState } from "react";

export default function TipCalculator() {
  const [bill, setBill] = useState(85);
  const [tipPercent, setTipPercent] = useState(18);
  const [people, setPeople] = useState(2);

  const tipAmount = bill * (tipPercent / 100);
  const total = bill + tipAmount;
  const perPerson = people > 0 ? total / people : total;
  const tipPerPerson = people > 0 ? tipAmount / people : tipAmount;

  const fmt = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD" });
  const presets = [10, 15, 18, 20, 25];

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Tip Calculator
      </h3>

      <div className="grid sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Bill Amount ($)</label>
          <input type="number" value={bill} onChange={(e) => setBill(Number(e.target.value))} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono text-sm" />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Tip: {tipPercent}%</label>
          <input type="range" min={0} max={50} value={tipPercent} onChange={(e) => setTipPercent(Number(e.target.value))} className="w-full accent-brand-500 mt-2" />
          <div className="flex gap-1.5 mt-2">
            {presets.map((p) => (
              <button key={p} onClick={() => setTipPercent(p)} className={`px-2 py-1 text-xs font-bold rounded-lg cursor-pointer transition-fast ${tipPercent === p ? "bg-brand-500 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500"}`}>
                {p}%
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Split Between</label>
          <input type="number" min={1} value={people} onChange={(e) => setPeople(Math.max(1, Number(e.target.value)))} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono text-sm" />
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-brand-50 dark:bg-brand-950/20 border border-brand-200 dark:border-brand-900/30 rounded-xl text-center">
          <div className="text-[10px] text-brand-500 font-bold uppercase mb-1">Tip Amount</div>
          <div className="text-xl font-bold font-mono text-brand-600 dark:text-brand-400">{fmt(tipAmount)}</div>
        </div>
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-center">
          <div className="text-[10px] text-slate-400 font-bold uppercase mb-1">Grand Total</div>
          <div className="text-xl font-bold font-mono text-slate-800 dark:text-white">{fmt(total)}</div>
        </div>
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/30 rounded-xl text-center">
          <div className="text-[10px] text-emerald-500 font-bold uppercase mb-1">Per Person</div>
          <div className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400">{fmt(perPerson)}</div>
        </div>
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-center">
          <div className="text-[10px] text-slate-400 font-bold uppercase mb-1">Tip/Person</div>
          <div className="text-xl font-bold font-mono text-slate-800 dark:text-white">{fmt(tipPerPerson)}</div>
        </div>
      </div>
    </div>
  );
}
