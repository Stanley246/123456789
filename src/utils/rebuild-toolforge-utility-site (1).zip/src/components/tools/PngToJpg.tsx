import { useState, useRef } from "react";
import Icon from "../Icon";

export default function PngToJpg() {
  const [image, setImage] = useState<string | null>(null);
  const [converted, setConverted] = useState<string | null>(null);
  const [quality, setQuality] = useState(0.9);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setImage(ev.target?.result as string);
      setConverted(null);
    };
    reader.readAsDataURL(file);
  };

  const convert = () => {
    if (!image) return;
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      setConverted(canvas.toDataURL("image/jpeg", quality));
    };
    img.src = image;
  };

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        PNG to JPG Converter
      </h3>

      {!image ? (
        <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-brand-500 p-12 rounded-2xl text-center cursor-pointer transition-all group">
          <input type="file" ref={fileInputRef} onChange={handleFile} accept="image/png" className="hidden" />
          <div className="p-4 bg-white dark:bg-slate-800 rounded-full shadow-md inline-block mb-4 text-slate-400 group-hover:text-brand-500 transition-colors">
            <Icon name="FileImage" className="w-8 h-8" />
          </div>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Upload a PNG image</p>
          <p className="text-xs text-slate-400 mt-1">Click to browse. 100% browser-based conversion.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-xs font-bold text-slate-400 uppercase mb-2">Original PNG</div>
              <img src={image} alt="PNG" className="max-h-48 mx-auto object-contain rounded-lg border border-slate-200 dark:border-slate-700" />
            </div>
            {converted && (
              <div className="text-center">
                <div className="text-xs font-bold text-emerald-500 uppercase mb-2">Converted JPG</div>
                <img src={converted} alt="JPG" className="max-h-48 mx-auto object-contain rounded-lg border border-slate-200 dark:border-slate-700" />
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-500 mb-2 block">Quality: {Math.round(quality * 100)}%</label>
            <input type="range" min={0.1} max={1} step={0.05} value={quality} onChange={(e) => setQuality(Number(e.target.value))} className="w-full accent-brand-500" />
          </div>

          <div className="flex gap-3">
            <button onClick={convert} className="px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-fast cursor-pointer">Convert to JPG</button>
            {converted && (
              <a href={converted} download="converted.jpg" className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold rounded-lg transition-fast inline-flex items-center gap-1 cursor-pointer">
                <Icon name="Download" className="w-4 h-4" /> Download JPG
              </a>
            )}
            <button onClick={() => { setImage(null); setConverted(null); }} className="px-4 py-2.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-sm font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer">Reset</button>
          </div>
        </div>
      )}
    </div>
  );
}
