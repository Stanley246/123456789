import { useState } from "react";

export default function BusinessName() {
  const [keyword, setKeyword] = useState("");
  const [industry, setIndustry] = useState("");
  const [names, setNames] = useState<{ category: string; items: string[] }[]>([]);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const generate = () => {
    if (!keyword.trim()) return;
    setLoading(true);
    setTimeout(() => {
      const k = keyword.trim();
      const K = k.charAt(0).toUpperCase() + k.slice(1);
      setNames([
        {
          category: "🏢 Professional",
          items: [`${K}Pro`, `${K}Hub`, `The ${K} Group`, `${K} Solutions`, `${K} & Co.`, `${K} Partners`],
        },
        {
          category: "🚀 Modern & Trendy",
          items: [`${K}ly`, `${K}ify`, `Nova${K}`, `${K}Wave`, `${K}Stack`, `Go${K}`],
        },
        {
          category: "💡 Creative",
          items: [`${K}Spark`, `${K}Forge`, `${K}Vault`, `${K}Bloom`, `${K}Pulse`, `${K}Craft`],
        },
        {
          category: "🌍 Domain-Friendly",
          items: [`get${k}.com`, `try${k}.io`, `use${k}.co`, `${k}app.com`, `${k}hq.com`, `my${k}.io`],
        },
      ]);
      setLoading(false);
    }, 600 + Math.random() * 500);
  };

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Business Name Generator
      </h3>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Main Keyword</label>
          <input type="text" value={keyword} onChange={(e) => setKeyword(e.target.value)} placeholder="e.g., tech, design, health..." onKeyDown={(e) => e.key === "Enter" && generate()} className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm" />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Industry (optional)</label>
          <input type="text" value={industry} onChange={(e) => setIndustry(e.target.value)} placeholder="e.g., SaaS, e-commerce, consulting..." className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm" />
        </div>
      </div>

      <button onClick={generate} disabled={!keyword.trim() || loading} className="px-5 py-2.5 bg-brand-500 hover:bg-brand-600 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white text-sm font-semibold rounded-lg transition-fast disabled:cursor-not-allowed cursor-pointer">
        {loading ? "Generating..." : "Generate Names"}
      </button>

      {names.length > 0 && !loading && (
        <div className="space-y-4">
          {names.map((group) => (
            <div key={group.category}>
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">{group.category}</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {group.items.map((name) => (
                  <button
                    key={name}
                    onClick={() => { navigator.clipboard.writeText(name); setCopied(name); setTimeout(() => setCopied(null), 2000); }}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer group"
                  >
                    <div className="text-sm font-bold text-slate-800 dark:text-slate-200">{name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5 group-hover:text-brand-500">
                      {copied === name ? "✓ Copied!" : "Click to copy"}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
