import { useState } from "react";

export default function LoanCalculator() {
  const [amount, setAmount] = useState(25000);
  const [rate, setRate] = useState(6.5);
  const [years, setYears] = useState(5);
  const [result, setResult] = useState<{ monthly: number; total: number; interest: number } | null>(null);

  const calculate = () => {
    const P = amount;
    const r = rate / 100 / 12;
    const n = years * 12;
    const pmt = r === 0 ? P / n : (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    setResult({ monthly: pmt, total: pmt * n, interest: pmt * n - P });
  };

  const fmt = (n: number) =>
    n.toLocaleString("en-US", { style: "currency", currency: "USD" });

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Loan Calculator
      </h3>

      <div className="grid sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Loan Amount ($)</label>
          <input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono text-sm" />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Interest Rate (%)</label>
          <input type="number" step={0.1} value={rate} onChange={(e) => setRate(Number(e.target.value))} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono text-sm" />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Term (Years)</label>
          <input type="number" value={years} onChange={(e) => setYears(Number(e.target.value))} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono text-sm" />
        </div>
      </div>

      <button onClick={calculate} className="px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-xl transition-fast cursor-pointer">
        Calculate
      </button>

      {result && (
        <div className="grid sm:grid-cols-3 gap-3">
          <div className="p-4 bg-brand-50 dark:bg-brand-950/20 border border-brand-200 dark:border-brand-900/30 rounded-xl text-center">
            <div className="text-xs text-brand-500 font-bold uppercase mb-1">Monthly Payment</div>
            <div className="text-2xl font-bold font-mono text-brand-600 dark:text-brand-400">{fmt(result.monthly)}</div>
          </div>
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-center">
            <div className="text-xs text-slate-400 font-bold uppercase mb-1">Total Paid</div>
            <div className="text-xl font-bold font-mono text-slate-800 dark:text-white">{fmt(result.total)}</div>
          </div>
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-center">
            <div className="text-xs text-slate-400 font-bold uppercase mb-1">Total Interest</div>
            <div className="text-xl font-bold font-mono text-rose-500">{fmt(result.interest)}</div>
          </div>
        </div>
      )}
    </div>
  );
}
