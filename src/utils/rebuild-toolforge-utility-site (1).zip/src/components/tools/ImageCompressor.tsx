import { useState, useRef } from "react";
import Icon from "../Icon";

export default function ImageCompressor() {
  const [image, setImage] = useState<string | null>(null);
  const [compressed, setCompressed] = useState<string | null>(null);
  const [quality, setQuality] = useState(0.7);
  const [origSize, setOrigSize] = useState(0);
  const [compSize, setCompSize] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setOrigSize(file.size);
    const reader = new FileReader();
    reader.onload = (ev) => {
      setImage(ev.target?.result as string);
      setCompressed(null);
    };
    reader.readAsDataURL(file);
  };

  const compress = () => {
    if (!image) return;
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.drawImage(img, 0, 0);
      const dataUrl = canvas.toDataURL("image/jpeg", quality);
      setCompressed(dataUrl);
      const base64 = dataUrl.split(",")[1];
      setCompSize(Math.ceil((base64.length * 3) / 4));
    };
    img.src = image;
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(2)} MB`;
  };

  const reduction = origSize > 0 && compSize > 0 ? Math.round((1 - compSize / origSize) * 100) : 0;

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Image Compressor
      </h3>

      {!image ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-brand-500 p-12 rounded-2xl text-center cursor-pointer transition-all group"
        >
          <input type="file" ref={fileInputRef} onChange={handleFile} accept="image/*" className="hidden" />
          <div className="p-4 bg-white dark:bg-slate-800 rounded-full shadow-md inline-block mb-4 text-slate-400 group-hover:text-brand-500 transition-colors">
            <Icon name="ImageDown" className="w-8 h-8" />
          </div>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
            Drop an image or click to browse
          </p>
          <p className="text-xs text-slate-400 mt-1">
            Supports JPEG, PNG, WebP. 100% browser-based.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-xs font-bold text-slate-400 uppercase mb-2">Original</div>
              <img src={image} alt="Original" className="max-h-48 mx-auto object-contain rounded-lg border border-slate-200 dark:border-slate-700" />
              <div className="text-xs text-slate-500 mt-2">{formatSize(origSize)}</div>
            </div>
            {compressed && (
              <div className="text-center">
                <div className="text-xs font-bold text-slate-400 uppercase mb-2">Compressed</div>
                <img src={compressed} alt="Compressed" className="max-h-48 mx-auto object-contain rounded-lg border border-slate-200 dark:border-slate-700" />
                <div className="text-xs text-emerald-500 font-bold mt-2">
                  {formatSize(compSize)} ({reduction}% smaller)
                </div>
              </div>
            )}
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <label className="text-xs font-semibold text-slate-500">Quality: {Math.round(quality * 100)}%</label>
            </div>
            <input
              type="range"
              min={0.1}
              max={1}
              step={0.05}
              value={quality}
              onChange={(e) => setQuality(Number(e.target.value))}
              className="w-full accent-brand-500"
            />
          </div>

          <div className="flex gap-3">
            <button onClick={compress} className="px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-white text-sm font-semibold rounded-lg transition-fast cursor-pointer">
              Compress
            </button>
            {compressed && (
              <a href={compressed} download="compressed-image.jpg" className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold rounded-lg transition-fast cursor-pointer inline-flex items-center gap-1">
                <Icon name="Download" className="w-4 h-4" /> Download
              </a>
            )}
            <button onClick={() => { setImage(null); setCompressed(null); }} className="px-4 py-2.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-sm font-semibold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer">
              Reset
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
