import { useState } from "react";

export default function CaseConverter() {
  const [text, setText] = useState("");
  const [output, setOutput] = useState("");

  const convert = (type: string) => {
    const t = text;
    switch (type) {
      case "upper": setOutput(t.toUpperCase()); break;
      case "lower": setOutput(t.toLowerCase()); break;
      case "title": setOutput(t.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())); break;
      case "sentence": setOutput(t.toLowerCase().replace(/(^\w|[.!?]\s+\w)/g, (c) => c.toUpperCase())); break;
      case "camel": setOutput(t.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (_, c) => c.toUpperCase())); break;
      case "pascal": setOutput(t.toLowerCase().replace(/(^|[^a-zA-Z0-9]+)(.)/g, (_, _s, c) => c.toUpperCase())); break;
      case "snake": setOutput(t.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "")); break;
      case "kebab": setOutput(t.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")); break;
      case "toggle": setOutput(t.split("").map((c) => c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase()).join("")); break;
      default: setOutput(t);
    }
  };

  const buttons = [
    { key: "upper", label: "UPPERCASE" },
    { key: "lower", label: "lowercase" },
    { key: "title", label: "Title Case" },
    { key: "sentence", label: "Sentence case" },
    { key: "camel", label: "camelCase" },
    { key: "pascal", label: "PascalCase" },
    { key: "snake", label: "snake_case" },
    { key: "kebab", label: "kebab-case" },
    { key: "toggle", label: "tOGGLE" },
  ];

  return (
    <div className="space-y-5">
      <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">
        Case Converter
      </h3>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text to convert..."
        className="w-full h-36 p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 text-sm resize-y font-sans"
      />

      <div className="flex flex-wrap gap-2">
        {buttons.map((b) => (
          <button
            key={b.key}
            onClick={() => convert(b.key)}
            disabled={!text.trim()}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-brand-50 dark:hover:bg-brand-950/20 border border-slate-200 dark:border-slate-700 hover:border-brand-300 dark:hover:border-brand-700 text-sm font-semibold text-slate-700 dark:text-slate-300 rounded-lg transition-fast disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            {b.label}
          </button>
        ))}
      </div>

      {output && (
        <div className="relative">
          <pre className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-900/60 text-slate-900 dark:text-white text-sm whitespace-pre-wrap font-sans">
            {output}
          </pre>
          <button
            onClick={() => navigator.clipboard.writeText(output)}
            className="absolute bottom-3 right-3 px-3 py-1.5 bg-slate-200 dark:bg-slate-800 text-xs font-bold rounded text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Copy
          </button>
        </div>
      )}
    </div>
  );
}
