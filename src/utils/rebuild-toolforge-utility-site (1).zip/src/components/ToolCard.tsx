import Icon from "./Icon";
import type { Tool, Category } from "../types";

interface ToolCardProps {
  tool: Tool;
  category: Category;
  isFavorite: boolean;
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  onClick: () => void;
}

export default function ToolCard({ tool, category, isFavorite, onToggleFavorite, onClick }: ToolCardProps) {
  return (
    <div
      onClick={onClick}
      className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/85 rounded-2xl p-5 hover:shadow-lg hover:shadow-slate-200/40 dark:hover:shadow-slate-900/40 hover:border-slate-300 dark:hover:border-slate-700 transition-all duration-200 cursor-pointer"
    >
      {/* Favorite Button */}
      <button
        onClick={(e) => onToggleFavorite(e, tool.id)}
        className="absolute top-3 right-3 p-1.5 text-slate-300 dark:text-slate-700 hover:text-red-500 dark:hover:text-red-500 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-fast cursor-pointer z-10"
      >
        <Icon
          name="Heart"
          className={`w-4 h-4 ${isFavorite ? "fill-red-500 text-red-500" : ""}`}
        />
      </button>

      {/* Icon */}
      <div className="p-2.5 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-xl w-fit mb-3 group-hover:bg-brand-50 dark:group-hover:bg-brand-950/20 group-hover:text-brand-500 transition-fast">
        <Icon name={tool.icon} className="w-5 h-5" />
      </div>

      {/* Content */}
      <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-1 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-fast">
        {tool.name}
      </h3>
      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">
        {tool.shortDescription}
      </p>

      {/* Category Tag */}
      <div className="mt-3">
        <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
          {category.name}
        </span>
      </div>
    </div>
  );
}
