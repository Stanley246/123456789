import Icon from "./Icon";
import type { Tool } from "../types";
import { CATEGORIES } from "../utils/completeToolsData";

interface SEOContentProps {
  tool: Tool;
}

export default function SEOContent({ tool }: SEOContentProps) {
  const category = CATEGORIES.find((c) => c.id === tool.categoryId);

  return (
    <div className="space-y-6 mt-6 animate-fade-in">
      {/* Structured About Section — key for SEO */}
      <article className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/85 rounded-2xl p-6 sm:p-8 space-y-4 text-left">
        <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Icon name={tool.icon} className="w-5 h-5 text-brand-500" />
          Free {tool.name} Online — ToolForge
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
          <strong>{tool.name}</strong> is a free, browser-based online tool from ToolForge.{" "}
          {tool.longDescription}{" "}
          Unlike other online tools that require file uploads or account creation, ToolForge's{" "}
          {tool.name} runs 100% inside your browser with zero data sent to any server. Your privacy
          is completely protected.
        </p>
        <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
          Whether you're a developer, student, marketer, or everyday user, our {tool.name} provides
          instant results with no limitations. Part of ToolForge's collection of{" "}
          <strong>600+ free online tools</strong> in the {category?.name || "Tools"} category.
        </p>

        {/* Trust Badges — reinforces authority */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800/50">
          {[
            { icon: "Shield", title: "100% Private", desc: "Runs in your browser" },
            { icon: "Zap", title: "Instant Results", desc: "No uploads needed" },
            { icon: "Globe", title: "100% Free", desc: "No account required" },
            { icon: "Lock", title: "No Data Stored", desc: "We never see your data" },
          ].map((badge) => (
            <div key={badge.title} className="text-center p-3">
              <div className="inline-flex p-2 bg-brand-50 dark:bg-brand-950/20 text-brand-500 rounded-xl mb-1.5">
                <Icon name={badge.icon} className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-200">{badge.title}</h4>
              <p className="text-[10px] text-slate-400 mt-0.5">{badge.desc}</p>
            </div>
          ))}
        </div>
      </article>

      {/* How to Use — great for featured snippets */}
      <article className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/85 rounded-2xl p-6 sm:p-8 space-y-3 text-left">
        <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
          How to Use {tool.name} on ToolForge
        </h3>
        <ol className="space-y-2.5 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
          <li className="flex gap-3">
            <span className="shrink-0 w-6 h-6 bg-brand-500 text-white text-xs font-bold rounded-full flex items-center justify-center">1</span>
            <span>Enter your input data in the field above — paste text, upload a file, or fill in the required fields for {tool.name}.</span>
          </li>
          <li className="flex gap-3">
            <span className="shrink-0 w-6 h-6 bg-brand-500 text-white text-xs font-bold rounded-full flex items-center justify-center">2</span>
            <span>Configure any options or settings to customize the {tool.name} output to your exact needs.</span>
          </li>
          <li className="flex gap-3">
            <span className="shrink-0 w-6 h-6 bg-brand-500 text-white text-xs font-bold rounded-full flex items-center justify-center">3</span>
            <span>Click the action button to process. Results from {tool.name} appear instantly — no waiting, no server uploads.</span>
          </li>
          <li className="flex gap-3">
            <span className="shrink-0 w-6 h-6 bg-brand-500 text-white text-xs font-bold rounded-full flex items-center justify-center">4</span>
            <span>Copy the result or download the output. Your data never leaves your browser when using ToolForge's {tool.name}.</span>
          </li>
        </ol>
      </article>

      {/* FAQ Section — excellent for search rankings */}
      <article className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/85 rounded-2xl p-6 sm:p-8 space-y-4 text-left">
        <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
          {tool.name} — Frequently Asked Questions
        </h3>
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Is the {tool.name} on ToolForge really free?</h4>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Yes! {tool.name} is 100% free to use with no limits, no accounts, and no hidden fees. Use it as many times as you want.</p>
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Is my data safe when I use {tool.name}?</h4>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Absolutely. ToolForge's {tool.name} processes everything directly in your browser using JavaScript. Your data never leaves your device — we have zero access to anything you input.</p>
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Does {tool.name} work on mobile devices?</h4>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Yes! ToolForge is fully responsive. {tool.name} works perfectly on phones, tablets, laptops, and desktops — any device with a modern web browser.</p>
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Do I need to install anything to use {tool.name}?</h4>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">No installation required. {tool.name} runs entirely in your web browser. Just visit the page and start using it immediately.</p>
          </div>
        </div>
      </article>

      {/* Keywords/Tags — help with internal linking and topic relevance */}
      {tool.keywords && tool.keywords.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider self-center mr-1">Related:</span>
          {tool.keywords.map((kw) => (
            <span
              key={kw}
              className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-medium rounded-full"
            >
              {kw}
            </span>
          ))}
          <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-medium rounded-full">
            free online tool
          </span>
          <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-medium rounded-full">
            ToolForge
          </span>
          <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-medium rounded-full">
            browser-based
          </span>
          <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-medium rounded-full">
            {category?.name || "utility"}
          </span>
        </div>
      )}
    </div>
  );
}
