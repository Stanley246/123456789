import { icons } from "lucide-react";

interface IconProps {
  name: string;
  className?: string;
}

export default function Icon({ name, className = "w-5 h-5" }: IconProps) {
  const LucideIcon = (icons as any)[name];
  if (!LucideIcon) {
    return <span className={className}>?</span>;
  }
  return <LucideIcon className={className} />;
}
