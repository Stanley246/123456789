export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface Tool {
  id: string;
  name: string;
  categoryId: string;
  icon: string;
  shortDescription: string;
  longDescription: string;
  keywords: string[];
}
